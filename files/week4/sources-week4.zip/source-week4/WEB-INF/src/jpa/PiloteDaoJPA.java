package jpa;

import java.util.List;

import javax.persistence.EntityManager;

import api.dao.PiloteDao;
import api.model.Pilote;


public class PiloteDaoJPA implements PiloteDao {
	
	public EntityManager em;
	
	/* (non-Javadoc)
	 * @see jpa.PiloteDao#create(java.lang.String, java.lang.String)
	 */
	@Override
	public Pilote create(String firstName, String lastName) {
		// TODO : implement this.
		throw new RuntimeException("Not yet implemented.");
	}
	
	/* (non-Javadoc)
	 * @see jpa.PiloteDao#listAll()
	 */
	@Override
	public List<Pilote> listAll() {
		// TODO : implement this.
		throw new RuntimeException("Not yet implemented.");
	}
	
	/* (non-Javadoc)
	 * @see jpa.PiloteDao#find(long)
	 */
	@Override
	public Pilote find(long id) {
		// TODO : implement this.
		throw new RuntimeException("Not yet implemented.");
	}
	
	/* (non-Javadoc)
	 * @see jpa.PiloteDao#update(api.model.Pilot)
	 */
	@Override
	public boolean update( Pilote pilot ) {
		// TODO : implement this.
		throw new RuntimeException("Not yet implemented.");
	}
	
	/* (non-Javadoc)
	 * @see jpa.PiloteDao#delete(long)
	 */
	@Override
	public boolean delete( long id ) {
		// TODO : implement this.
		throw new RuntimeException("Not yet implemented.");
	}
	
	/* (non-Javadoc)
	 * @see jpa.PiloteDao#deleteAll()
	 */
	@Override
	public boolean deleteAll( ) {
		// TODO : implement this.
		throw new RuntimeException("Not yet implemented.");
	}

}
