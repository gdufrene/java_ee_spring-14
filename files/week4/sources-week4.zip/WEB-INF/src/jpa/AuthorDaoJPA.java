package jpa;

import java.util.List;

import javax.persistence.EntityManager;

import api.dao.AuthorDao;
import api.model.Author;


public class AuthorDaoJPA implements AuthorDao {
	
	public EntityManager em;
	
	/* (non-Javadoc)
	 * @see jpa.AuthorDao#create(java.lang.String, java.lang.String)
	 */
	@Override
	public Author create(String firstName, String lastName) {
		// TODO : implement this.
		throw new RuntimeException("Not yet implemented.");
	}
	
	/* (non-Javadoc)
	 * @see jpa.AuthorDao#listAll()
	 */
	@Override
	public List<Author> listAll() {
		// TODO : implement this.
		throw new RuntimeException("Not yet implemented.");
	}
	
	/* (non-Javadoc)
	 * @see jpa.AuthorDao#find(long)
	 */
	@Override
	public Author find(long id) {
		// TODO : implement this.
		throw new RuntimeException("Not yet implemented.");
	}
	
	/* (non-Javadoc)
	 * @see jpa.AuthorDao#update(api.model.Author)
	 */
	@Override
	public boolean update( Author author ) {
		// TODO : implement this.
		throw new RuntimeException("Not yet implemented.");
	}
	
	/* (non-Javadoc)
	 * @see jpa.AuthorDao#delete(long)
	 */
	@Override
	public boolean delete( long id ) {
		// TODO : implement this.
		throw new RuntimeException("Not yet implemented.");
	}
	
	/* (non-Javadoc)
	 * @see jpa.AuthorDao#deleteAll()
	 */
	@Override
	public boolean deleteAll( ) {
		// TODO : implement this.
		throw new RuntimeException("Not yet implemented.");
	}

}
