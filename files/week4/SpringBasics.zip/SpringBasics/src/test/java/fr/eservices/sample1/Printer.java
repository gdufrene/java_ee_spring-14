package fr.eservices.sample1;

public class Printer {
	
	public Printer() {}
	
	public void print(String message) {
		System.out.println( message );
	}

}
