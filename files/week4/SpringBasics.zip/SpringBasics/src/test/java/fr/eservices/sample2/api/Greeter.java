package fr.eservices.sample2.api;


public interface Greeter {
	/**
	 * Say Hello to someOne
	 * 
	 * @param name
	 * @return the complete hello sentence
	 */
	public String hello( String name );
}
