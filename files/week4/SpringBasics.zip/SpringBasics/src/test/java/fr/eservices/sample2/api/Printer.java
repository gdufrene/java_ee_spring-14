package fr.eservices.sample2.api;

public interface Printer {
	/**
	 * Print a message
	 * 
	 * @param message
	 */
	public void print(String message);
}
