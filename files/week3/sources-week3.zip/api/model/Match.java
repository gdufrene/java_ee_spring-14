package api.model;

public class Match {

}
