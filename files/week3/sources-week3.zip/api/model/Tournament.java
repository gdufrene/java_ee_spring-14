package api.model;

public class Tournament {

}
