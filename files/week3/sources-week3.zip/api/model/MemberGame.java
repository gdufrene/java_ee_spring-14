package api.model;

public class MemberGame {

}
