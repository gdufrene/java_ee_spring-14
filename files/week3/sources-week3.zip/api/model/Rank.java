package api.model;

public enum Rank {
	
	BEGINER,
	MODERATE,
	CONFIRMED,
	EXPERT

}
