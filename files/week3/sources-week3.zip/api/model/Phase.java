package api.model;

public class Phase {

}
