package api.model;

public class Member {

}
