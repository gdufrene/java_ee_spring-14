package api.model;

public class Result {

}
