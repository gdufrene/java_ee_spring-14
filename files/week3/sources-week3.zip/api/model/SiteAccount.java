package api.model;

public class SiteAccount {

}
