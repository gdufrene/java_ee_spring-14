package api.model;

public class OnlinePortal {

}
